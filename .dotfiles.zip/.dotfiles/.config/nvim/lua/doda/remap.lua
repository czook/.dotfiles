local nnoremap = require("doda.keymap").nnoremap

-- Exit vim to netrw
nnoremap("<leader>r", "<cmd>Ex<CR>")
nnoremap("<leader>w", "<cmd>w<CR>")
nnoremap("<leader>q", "<cmd>wq<CR>")
-- telescope keybinds
nnoremap("<leader>ff", "<cmd>lua require('telescope.builtin').find_files()<cr>")
nnoremap("<leader>fg", "<cmd>lua require('telescope.builtin').live_grep()<cr>")
-- UndoTree keybinds
nnoremap("<leader>uu", "<cmd>UndotreeToggle<CR>")
-- lspconfig keybinds
nnoremap("<leader>gh", "<cmd>lua vim.lsp.buf.hover()<cr>")
nnoremap("<leader>gd", "<cmd>lua vim.lsp.buf.definition<cr>")
nnoremap("<leader>gD", "<cmd>lua vim.lsp.buf.declaration()<cr>")
nnoremap("<leader>gi", "<cmd>lua vim.lsp.buf.implementation()<cr>")
nnoremap("<leader>gr", "<cmd>lua vim.lsp.buf.references()<cr>")
nnoremap("<leader>go", "<cmd>lua vim.lsp.buf.type_definition()<cr>")
