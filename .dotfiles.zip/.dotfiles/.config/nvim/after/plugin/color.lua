vim.g.neon_style = "dark"
vim.g.neon_italic_keyword = true
vim.g.neon_italic_funciton = true
vim.g.neon_transparent = true

vim.cmd[[colorscheme neon]]
